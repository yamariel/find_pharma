class PharmacyCard {
  
}