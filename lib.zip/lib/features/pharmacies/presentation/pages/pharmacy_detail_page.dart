class PharmacyDetailPage {
  
}