class Pharmacy {
  
}