class GetOnDutyPharmaciesUsecase {
  
}