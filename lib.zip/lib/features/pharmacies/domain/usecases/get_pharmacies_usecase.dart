class GetPharmaciesUsecase {
  
}