class PharmacyRepository {
  
}