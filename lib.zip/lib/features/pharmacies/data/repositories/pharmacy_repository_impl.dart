class PharmacyRepositoryImpl {
  
}