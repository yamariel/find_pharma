class PharmacyModel {
  
}