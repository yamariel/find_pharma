class PharmacyRemoteDataSource {
  
}