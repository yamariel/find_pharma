class ChatBubble {
  
}