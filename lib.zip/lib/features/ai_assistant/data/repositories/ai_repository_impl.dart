class AiRepositoryImpl{
  
}