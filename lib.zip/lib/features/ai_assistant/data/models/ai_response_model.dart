class AiResponseModel {
  
}