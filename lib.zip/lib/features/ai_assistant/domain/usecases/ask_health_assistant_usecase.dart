class AskHealthAssistantUsecase {
  
}