class AiRepository {
  
}