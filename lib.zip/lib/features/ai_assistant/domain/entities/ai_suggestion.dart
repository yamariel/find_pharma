class AiSuggestion {
  
}