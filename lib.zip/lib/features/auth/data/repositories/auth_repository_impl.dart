class AuthRepositoryImpl {
  
}