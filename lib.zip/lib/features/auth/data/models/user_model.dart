class UserModel {
  
}