class LogoutUsecase {
  
}