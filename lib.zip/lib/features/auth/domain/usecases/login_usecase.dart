class LoginUsecase {
  
}