class RegisterUsecase {
  
}