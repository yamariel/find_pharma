class AuthRepository {
  
}