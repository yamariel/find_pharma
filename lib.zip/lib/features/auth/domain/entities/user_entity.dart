class UserEntity {
  
}