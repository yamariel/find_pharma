import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:find_pharma/core/utils/medicine_ui.dart';
import '../../domain/entities/medicine.dart';
import '../providers/medicine_provider.dart';
import '../widgets/medicine_card.dart';
import '../widgets/medicine_search_bar.dart';
import '../widgets/medicine_detail_view.dart';

/// Écran : barre de recherche -> liste de résultats -> page du médicament.
class SearchMedicinesPage extends ConsumerStatefulWidget {
  /// Si renseigné, lance la recherche au démarrage et ouvre le 1er résultat.
  final String initialQuery;
  const SearchMedicinesPage({super.key, this.initialQuery = ''});

  @override
  ConsumerState<SearchMedicinesPage> createState() => _SearchMedicinesPageState();
}

class _SearchMedicinesPageState extends ConsumerState<SearchMedicinesPage> {
  late final TextEditingController _controller;
  Timer? _debounce;
  Medicine? _selected;
  bool _autoSelectFirst = false;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialQuery);
    if (widget.initialQuery.isNotEmpty) {
      _autoSelectFirst = true;
      WidgetsBinding.instance.addPostFrameCallback((_) => ref
          .read(medicineSearchProvider.notifier)
          .search(widget.initialQuery));
    }
  }

  @override
  void dispose() {
    _debounce?.cancel();
    _controller.dispose();
    super.dispose();
  }

  /// Debounce : on attend 300 ms sans frappe avant d'interroger la base.
  void _onChanged(String text) {
    _debounce?.cancel();
    _autoSelectFirst = false;
    setState(() => _selected = null);
    _debounce = Timer(const Duration(milliseconds: 300),
        () => ref.read(medicineSearchProvider.notifier).search(text));
  }

  @override
  Widget build(BuildContext context) {
    ref.listen<AsyncValue<List<Medicine>>>(medicineSearchProvider, (_, next) {
      if (!_autoSelectFirst) return;
      next.whenData((list) {
        if (list.isNotEmpty) {
          _autoSelectFirst = false;
          setState(() => _selected = list.first);
        }
      });
    });
    final results = ref.watch(medicineSearchProvider);

    return Scaffold(
      backgroundColor: MedicineColors.background,
      appBar: AppBar(
        backgroundColor: MedicineColors.background,
        elevation: 0,
        title: const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('FINDPHARMA',
                style: TextStyle(fontSize: 11, color: MedicineColors.textMuted)),
            Text('Médicaments',
                style: TextStyle(fontWeight: FontWeight.w800, fontSize: 20)),
          ],
        ),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
            child: MedicineSearchBar(
              controller: _controller,
              onChanged: _onChanged,
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: MedicineColors.primaryLight,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline,
                      size: 18, color: MedicineColors.primary),
                  SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Les disponibilités sont déclaratives. Vérifiez toujours '
                      'auprès de la pharmacie par appel direct avant de vous déplacer.',
                      style: TextStyle(fontSize: 12.5),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Expanded(child: _body(results)),
        ],
      ),
    );
  }

  Widget _body(AsyncValue<List<Medicine>> results) {
    if (_selected != null) {
      return MedicineDetailView(
        medicine: _selected!,
        onSelectAlternative: (m) => setState(() => _selected = m),
      );
    }
    return results.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (e, _) => Center(child: Text('$e')),
      data: (list) {
        if (list.isEmpty) {
          return const Center(
            child: Text('Tapez le nom d\u2019un médicament (2 lettres min.)',
                style: TextStyle(color: MedicineColors.textMuted)),
          );
        }
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
          children: [
            for (final m in list)
              MedicineCard(
                  medicine: m, onTap: () => setState(() => _selected = m)),
          ],
        );
      },
    );
  }
}
