import 'package:flutter/material.dart';
import '../../domain/entities/medicine.dart';
import 'package:find_pharma/core/utils/medicine_ui.dart';

/// Carte d'un médicament dans la liste de résultats de recherche.
class MedicineCard extends StatelessWidget {
  final Medicine medicine;
  final VoidCallback? onTap;
  const MedicineCard({super.key, required this.medicine, this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      color: MedicineColors.surface,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
        leading: const CircleAvatar(
          backgroundColor: MedicineColors.primaryLight,
          child: Icon(Icons.medication_outlined, color: MedicineColors.primary),
        ),
        title: Text(medicine.name,
            style: const TextStyle(fontWeight: FontWeight.w700)),
        subtitle: Text('${medicine.form} • Boîte de ${medicine.packSize}\n'
            'Lab: ${medicine.lab} • DCI: ${medicine.dci}'),
        isThreeLine: true,
        trailing: const Icon(Icons.chevron_right),
      ),
    );
  }
}
