import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:find_pharma/core/utils/medicine_ui.dart';
import '../../domain/entities/medicine.dart';
import '../providers/medicine_provider.dart';
import 'availability_tile.dart';
import 'alternative_card.dart';

/// La "page du médicament" de la maquette :
/// produit recherché + disponibilité à proximité + alternatives économiques.
class MedicineDetailView extends ConsumerWidget {
  final Medicine medicine;
  final ValueChanged<Medicine>? onSelectAlternative;
  const MedicineDetailView(
      {super.key, required this.medicine, this.onSelectAlternative});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final stock = ref.watch(pharmaciesWithStockProvider(medicine.id));
    final alternatives = ref.watch(genericAlternativesProvider(medicine));

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      children: [
        const _SectionLabel('PRODUIT RECHERCHÉ'),
        Card(
          elevation: 0,
          color: MedicineColors.surface,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(medicine.name,
                          style: const TextStyle(
                              fontSize: 20, fontWeight: FontWeight.w800)),
                    ),
                    _Badge(medicine.isGeneric ? 'Générique' : 'Référence'),
                  ],
                ),
                const SizedBox(height: 4),
                Text('${medicine.form} • Boîte de ${medicine.packSize}',
                    style: const TextStyle(color: MedicineColors.textMuted)),
                Text('Lab: ${medicine.lab} • DCI: ${medicine.dci}',
                    style: const TextStyle(
                        color: MedicineColors.textMuted, fontSize: 13)),
                const SizedBox(height: 16),
                const _SectionLabel('DISPONIBILITÉ À PROXIMITÉ'),
                stock.when(
                  loading: () => const Padding(
                    padding: EdgeInsets.all(12),
                    child: Center(child: CircularProgressIndicator()),
                  ),
                  error: (e, _) => Text('$e'),
                  data: (items) {
                    if (items.isEmpty) {
                      return const Text(
                          "Aucune pharmacie n'a ce médicament en stock pour le moment.",
                          style: TextStyle(color: MedicineColors.textMuted));
                    }
                    final sorted = [...items]..sort((a, b) =>
                        (a.distanceKm ?? 999).compareTo(b.distanceKm ?? 999));
                    return Column(children: [
                      for (var i = 0; i < sorted.length; i++)
                        AvailabilityTile(item: sorted[i], highlight: i == 0),
                    ]);
                  },
                ),
              ],
            ),
          ),
        ),
        alternatives.maybeWhen(
          data: (list) => list.isEmpty
              ? const SizedBox.shrink()
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    Row(children: [
                      const Icon(Icons.autorenew,
                          color: MedicineColors.primary, size: 20),
                      const SizedBox(width: 6),
                      const Text('Alternatives économiques',
                          style: TextStyle(
                              fontSize: 17, fontWeight: FontWeight.w800)),
                    ]),
                    const SizedBox(height: 4),
                    const Text(
                        'Même molécule active, efficacité thérapeutique équivalente.',
                        style: TextStyle(color: MedicineColors.textMuted)),
                    const SizedBox(height: 10),
                    for (final alt in list)
                      AlternativeCard(
                        medicine: alt,
                        onTap: onSelectAlternative == null
                            ? null
                            : () => onSelectAlternative!(alt),
                      ),
                  ],
                ),
          orElse: () => const SizedBox.shrink(),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: MedicineColors.primaryLight,
            borderRadius: BorderRadius.circular(14),
          ),
          child: const Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.verified_user_outlined, color: MedicineColors.primary),
              SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Transparence des stocks : dernière vérification du stock '
                  'indiquée pour chaque officine. Aucune garantie contractuelle : '
                  'les flux au comptoir restent prioritaires.',
                  style: TextStyle(fontSize: 13),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 8, top: 4),
        child: Text(text,
            style: const TextStyle(
                fontSize: 11.5,
                letterSpacing: 0.6,
                fontWeight: FontWeight.w700,
                color: MedicineColors.textMuted)),
      );
}

class _Badge extends StatelessWidget {
  final String text;
  const _Badge(this.text);
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: MedicineColors.primaryLight,
          borderRadius: BorderRadius.circular(8),
        ),
        child: Text(text,
            style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: MedicineColors.primary)),
      );
}
