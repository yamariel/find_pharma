class MapLocationModel {
  
}