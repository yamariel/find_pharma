class GetLocationsUsecase {
  
}