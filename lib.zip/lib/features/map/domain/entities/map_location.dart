class MapLocation {
  
}